﻿using System;
using static System.Console;

namespace CA2
{
    public class Program
    {

        public static void Main(string[] args)
        {
            //variables
            bool keepPlaying = true, anotherCard = true;
            string keepPlayingString = "", playerChoice = "", playerStick = "";
            int playerHand = 0, dealerHand = 0;
            int playerHandTotal = 0, dealerHandTotal = 0;

            List<Card> playerCards = new List<Card>();
            List<Card> dealerCards = new List<Card>();
            //Card[] playerHand2 = new Card[100];
            //Introduction
            WriteLine("Welcome to black jack");

            while (keepPlaying != false)//Keep playing game
            {
                bool motion = true; //resets to stop code breaking
                while (motion != false)
                {
                    //card generator
                    Deck deck1 = new Deck(); //creates a deck
                    deck1.Randomise(); //shuffles the deck

                    //this decides if the player wants to stick or fold
                    for (int i = 0; i < 2; i++)
                    {
                        Card card12 = deck1.DealCard(); //Dealing for player
                        WriteLine("\nPlayer");
                        WriteLine(card12); //cards for player
                        WriteLine($"Player card value is {card12.GetCardValue()}"); //Displays value of players card
                        playerHandTotal += card12.GetCardValue(); //calculate total players hand
                        WriteLine($"Total Value: {playerHandTotal}\n"); //display players total
                        playerCards.Add(card12); //add card to players hand list
                    }
                    Write("Would you like to stick or twist (Y/N): ");
                    playerStick = ReadLine().ToUpper();

                    if(playerStick == "Y")

                        for (int i = 0; i < 2; i++)
                        {
                            Card card2 = deck1.DealCard(); //Dealing for dealer
                            //Dealer hand
                            WriteLine("\nDealer");
                            WriteLine(card2); //cards for dealer
                            WriteLine($"Dealer card value is {card2.GetCardValue()}"); //Displays value of dealers card
                            dealerHandTotal += card2.GetCardValue(); //calculate total dealer hand
                            WriteLine($"Total Value {dealerHandTotal}"); //display dealers total
                            dealerCards.Add(card2); //add card to dealers hand list
                        }
                            if(dealerHandTotal <= 17)
                    {
                        Card card2 = deck1.DealCard(); //Dealing for dealer
                                                       //Dealer hand
                        WriteLine("\nDealer");
                        WriteLine(card2); //cards for dealer
                        WriteLine($"Dealer card value is {card2.GetCardValue()}"); //Displays value of dealers card
                        dealerHandTotal += card2.GetCardValue(); //calculate total dealer hand
                        WriteLine($"Total Value {dealerHandTotal}"); //display dealers total
                        dealerCards.Add(card2); //add card to dealers hand list
                    }

                    //dealing cards
                    while (anotherCard != false)// || playerHandTotal !> 21)
                    {


                        Write("\nWould you like another card?(Y/N): ");
                        playerChoice = ReadLine().ToUpper();

                        if (playerChoice == "Y")
                        {
                            anotherCard = true;
                            //Get card                           
                            Card card1 = deck1.DealCard(); //Dealing for player                          
                            //Display Card
                            //player Hand
                            WriteLine("\nPlayer");
                            WriteLine(card1); //cards for player
                            WriteLine($"Player card value is {card1.GetCardValue()}"); //Displays value of players card
                            playerHandTotal += card1.GetCardValue(); //calculate total players hand
                            WriteLine($"Total Value: {playerHandTotal}\n"); //display players total
                            playerCards.Add(card1); //add card to players hand list
                           
                       
                        }
                        else if (playerChoice == "N")
                        {
                            anotherCard = false;
                        }
                        else
                        {
                            WriteLine("Error");
                        }
                        
                    }

                    WriteLine($"\n{CalculateWinner(dealerHandTotal, playerHandTotal)}");
                    string outcome = ReadLine();
                    WriteLine(Scoreboard(outcome));

                    #region continuePlaying   
                    //   WriteLine("Test Code");                 
                    Write("Would you like to keep playing(Y/N): ");
                    keepPlayingString = ReadLine().ToUpper();
                        if (keepPlayingString == "Y")
                        {
                            keepPlaying = true;
                            motion = false;
                            anotherCard = true;
                            Console.Clear();
                            Console.WriteLine("New Game");
                        }
                        else if (keepPlayingString == "N")
                        {
                            keepPlaying = false;
                            motion = false;
                        }
                        else
                        {
                            WriteLine("Error");
                            motion = true;
                        }   
                }
            }//while (keep playing loop)
            #endregion continuePlaying 
        }//main method

        //This method will decide if the player wins, losses or draws to the dealer
        static private string CalculateWinner(int dealerHandTotal, int playerHandTotal)
        {
            //variables
            string message = "";
            int winningNumber = 21;
            int dealerLeft = 0, playerLeft = 0;
            //processing
            dealerLeft = winningNumber - dealerHandTotal; //finds out who has the closer number for dealer
            playerLeft = winningNumber - playerHandTotal; //finds out who has the closer number for dealer

            if (playerLeft > dealerLeft || playerHandTotal > 21)
            {
                message = "You Lost";
            }
            else if(playerLeft < dealerLeft)
            {
                message = "You Won";
            }
            else
            {
                message = "draw";
            }
            return message;
        }
        private static void DisplayCards(Deck deck1)
        {
            for (int i = 0; i < 52; i++)
            {
                Write($"{deck1.DealCard()}" + ", ");

            }
        }

        //additional Detail ------ Scoreboard
         static string Scoreboard(string outcome)
        {
            int wins = 0, loss = 0, draws = 0;
            if(outcome == "You Lost")
            {
                loss++;
            }
            else if(outcome == "You Won")
            {
                wins++;
            }
            else
            {
                draws++;
            }
            return "Wins:" + wins + "Losses: " + loss + "Draws" + draws;
        }
    }//class
} //namespace

