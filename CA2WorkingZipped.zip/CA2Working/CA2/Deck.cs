﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CA2
{
    public class Deck
    {
        private Card[] deck;
        private int currentCard;
        private const int NumberOfCards = 52;
        private Random ranNum = new Random();

        public Deck() 
        {
            string[] faces = {"Ace", "Two", "Three", "Four", "Five", "Six", "Seven",
            "Eight", "Nine", "Ten", "Jack", "Queen", "King"};
            string[] suits = { "Clubs", "Spades", "Hearts", "Diamonds" };

            deck = new Card[NumberOfCards];
            currentCard= 0;
            ranNum.Next(deck.Length-1);

            for (int counter = 0; counter < deck.Length; counter++)
                deck[counter] = new Card(faces[counter % 11], suits[counter / 13]);
        }

        //This method will randomise which cards are projected first.
        public void Randomise()
        {
            currentCard = 0;
            for (int first = 0; first < deck.Length; first++)
            {
                int second = ranNum.Next(NumberOfCards);
                Card temp = deck[first];
                deck[first] = deck[second];
                deck[second] = temp;
            }
        }

        //This method will deal the cards to the player and dealer
        public Card DealCard()
        {
            if (currentCard < deck.Length)
                return deck[currentCard++];
            else
                return null;
        }     
    }
}
