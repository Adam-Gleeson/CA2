﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CA2
{
    public class Card
    {
        private string face;
        private string suit;

        public Card(string cardFace, string cardSuit)
        {
            face = cardFace;
            suit = cardSuit;
        }

        public override string ToString()
        {
            return face + " of " + suit;
        }

        public int GetCardValue()
        {
            int value = 0;
            
            if (face == "Jack" || face == "Queen" || face == "King")
            {
                value = 10;
            }
            else if (face == "Ace")
            {
                value = 1;
            }
            else
            {
                switch (face)
                {
                    case "Two": value = 2; break;
                    case "Three": value = 3; break;
                    case "Four": value = 4; break;
                    case "Five": value = 5; break;
                    case "Six": value = 6; break;
                    case "Seven": value = 7; break;
                    case "Eight": value = 8; break;
                    case "Nine": value = 9; break;
                    default: value = 10; break;

                }

            }
            return value;
            //if king, queen, jack - value is 10
            //ace is 1
            //all others are face value  - 2 is 2 etc
        }
        public int DecideAce()
        {
            int value = 0;
            if(face == "Ace")
            {
                value = 11;
            }
            else
            {

            }

            return value;
        }
    }
}
